from setuptools import setup

setup(
    name='abdisbook_hfunctions',
    author='Abdi Timer'
)