# Helper Module to support Abdis Machine Learning Handbook

This module contains code that supports abdis machine learning handbook.